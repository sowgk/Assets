# Colors
- Background - #2B2A30
- Red - #9d0000
- Green - #00aa51

# Typography
- **Timer Amount** - Bebas Neue - Book
- **Start/Stop** - [Montserrat](https://fonts.google.com/specimen/Montserrat?query=mont) - Bold
